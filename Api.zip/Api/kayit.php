        <?php 

require 'autoload.php';
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;
$usernamee = '';
$passwordd = '';
$user = $_POST["userid"];
$ig = new \InstagramAPI\Instagram();

try{
    $ig->login($usernamee, $passwordd);
} catch(\Exception $e){
    echo $e->getMessage();
}

?>