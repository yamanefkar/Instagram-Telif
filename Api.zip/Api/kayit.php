        <?php 

require 'autoload.php';
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;
$usernamee = 'bilalx.tr';
$passwordd = '123456789asd';
$user = $_POST["userid"];
$ig = new \InstagramAPI\Instagram();

try{
    $ig->login($usernamee, $passwordd);
} catch(\Exception $e){
    echo $e->getMessage();
}

?>