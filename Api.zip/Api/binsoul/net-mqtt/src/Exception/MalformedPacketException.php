<?php

namespace BinSoul\Net\Mqtt\Exception;

/**
 * Will be thrown if a packet is malformed.
 */
class MalformedPacketException extends \Exception
{
}
